RELATÓRIO DE REVISÃO - ELETRÔNICA BÁSICA

Arquivo principal para compilação no Overleaf: main.tex

Estrutura:
- main.tex                 : documento principal
- configuracao.tex         : pacotes, margens, cabeçalhos e padrões
- capa.tex                 : capa institucional com logo da UNIVALI
- secoes/                  : objetivos, introdução e conclusão
- exercicios/              : um arquivo .tex por exercício
- figuras/                 : imagens organizadas por exercício
- relatorio_revisao.pdf    : versão compilada do relatório

Compilador recomendado: pdfLaTeX.
