RELATÓRIO 1 - ELETRÔNICA BÁSICA

Pacote preparado para Overleaf.

Arquivo principal: main.tex
Compilador recomendado: pdfLaTeX

Estrutura:
- capa.tex: capa institucional
- configuracao.tex: pacotes e padronização
- secoes/: objetivos, introdução e conclusão
- exercicios/: um arquivo .tex por exercício
- figuras/: imagens organizadas por exercício
- relatorio_1.pdf: versão compilada do relatório

Observação: os cálculos foram tipografados em LaTeX e as capturas do Multisim foram preservadas a partir do documento Word fornecido.
