Relatório 5 - Retificadores em Ponte e Filtros Capacitivos

Arquivo principal: main.tex
Compilador recomendado: pdfLaTeX

Estrutura:
- main.tex: documento principal
- configuracao.tex: pacotes, margens e estilo
- capa.tex: capa institucional
- secoes/: objetivos, introdução e conclusão
- exercicios/: um arquivo .tex por exercício
- figuras/: imagens organizadas por exercício
- relatorio_5.pdf: PDF compilado

Observações de revisão técnica:
- O Exercício 2 foi corrigido explicitamente para a topologia de ponte mostrada no enunciado, pois a base Word continha equações de center tap.
- No Exercício 4, a análise de ripple foi revisada para onda completa (fr = 2f), e a inconsistência aritmética do PIV da base foi sinalizada no texto.
- As correções foram identificadas no próprio relatório; os valores medidos e as figuras do arquivo-base foram preservados.

Para usar no Overleaf, envie o conteúdo deste diretório e defina main.tex como arquivo principal.
