RELATÓRIO 3 - CIRCUITOS CEIFADORES E GRAMPEADORES

Projeto preparado para Overleaf.

Arquivo principal: main.tex
Compilador recomendado: pdfLaTeX

Estrutura:
- main.tex: documento principal
- configuracao.tex: pacotes e configuração visual
- capa.tex: capa institucional
- secoes/: objetivo, introdução e conclusão
- exercicios/: um arquivo .tex por exercício
- figuras/: imagens organizadas por exercício
- logo_univali.png: logo usada na capa
- relatorio_3.pdf: versão compilada
