RELATÓRIO 2 - ELETRÔNICA BÁSICA

Projeto preparado para Overleaf / pdfLaTeX.

Arquivo principal:
  main.tex

Estrutura:
  main.tex
  configuracao.tex
  capa.tex
  secoes/
  exercicios/
  figuras/
  logo_univali.png

Para compilar no Overleaf:
1. Envie todos os arquivos e pastas mantendo a estrutura.
2. Defina main.tex como Main document.
3. Utilize o compilador pdfLaTeX.

Observações de consistência incorporadas ao relatório:
- O cálculo de resistência dinâmica do rascunho apresenta uma inconsistência aritmética; a versão LaTeX recalcula usando os pontos escritos no próprio documento.
- No modelo linear do Exercício 2, a captura do Multisim mostra Vo = 2,552 V, enquanto o texto do Word registra 2,252 V; a versão LaTeX adota o valor visível na instrumentação e explica a diferença.
- No Exercício 3 foi aplicado o modelo simplificado solicitado, incluindo a queda de 0,7 V no cálculo da corrente direta.
