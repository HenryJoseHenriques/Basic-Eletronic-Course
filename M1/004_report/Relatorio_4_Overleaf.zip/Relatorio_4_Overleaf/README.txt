Relatório 4 - Retificadores de Meia Onda e Onda Completa

Arquivo principal: main.tex
Compilador recomendado: pdfLaTeX

Estrutura:
- main.tex: documento principal
- configuracao.tex: pacotes, margens e estilo
- capa.tex: capa institucional
- secoes/: objetivo, introdução e conclusão
- exercicios/: um arquivo .tex por exercício
- figuras/: imagens organizadas por exercício
- relatorio_4.pdf: PDF compilado

Para usar no Overleaf, envie o conteúdo deste diretório e defina main.tex como arquivo principal.
